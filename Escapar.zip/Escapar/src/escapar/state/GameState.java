package escapar.state;

import escapar.main.World;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JLabel;

import escapar.gfx.Images;
import escapar.main.*;

public class GameState extends State implements Iterations {
	//ATTRIBUTES
	private World level; //a game state has-a world
	
	//CONSTRUCTOR
	public GameState(World world, Escapar game) {
		super(world, game);
		level = new World(game,"res/levels/level1.txt");
		world = level;
	}

	
	@Override
	//updates level (world)
	public void update() {
		level.update();
	}

	@Override
	//draws contents of the game state (i.e world, and counter)
	public void draw(Graphics g) {
		level.draw(g);
		g.setColor(Color.YELLOW);
		g.setFont(new Font("Lucida Console", Font.BOLD, 18));
		g.drawString("Health : "+ level.getPablo().getHealth(), 700, 24);
		g.drawString("Score : "+ level.getPablo().getScore(), 700, 40);
	}

	
}
