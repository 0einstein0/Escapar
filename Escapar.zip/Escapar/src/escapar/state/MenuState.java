package escapar.state;

import escapar.main.World;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import escapar.gfx.Images;
import escapar.handler.*;
import escapar.main.*;

public class MenuState extends State implements Iterations{
	
	private boolean aboutscreen;
	
	//CONSTRUCTOR
	public MenuState(World world, Escapar game) {
		super(world, game);
	}

	@Override
	//update
	public void update() {
		//check if the start button (or alternatively, s) has been clicked, to shift to play state
		if (MouseHandler.startbutton || KeyHandler.s) {
			Escapar.currentstate = Escapar.play;
		}
		
	
		//update animation of background
		Images.menubg.update();
	}

	@Override
	//draw GUI
	public void draw(Graphics g) {
		
		g.setColor(Color.BLACK);
		g.drawImage(Images.menubg.getCurrentFrame(), -70, -15, 982, 700, null);
		g.setColor(Color.lightGray);
		g.drawImage(Images.startbutton, 320, 420, 250, 150, null);
		g.drawImage(Images.aboutbutton, 320, 550, 250, 150, null);
		g.drawImage(Images.title, 150, 100, 600, 400, null);
		
		if (MouseHandler.aboutbutton) {
			g.drawImage(Images.abouttext, 200, 80, 500, 500, null);
		}
		
		
	}

	

	
}
