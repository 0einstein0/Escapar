package escapar.state;

import escapar.main.World;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import escapar.gfx.Images;
import escapar.main.*;

public class PauseState extends State implements Iterations {
	
	//CONSTRUCTOR
	public PauseState(World world, Escapar game) {
		super(world, game);

	}

	@Override
	//update
	public void update() {
		//update background animation
		Images.pausebg.update();
	}

	@Override
	//draw GUI
	public void draw(Graphics g) {
		g.setColor(Color.gray);
		g.drawImage(Images.pausebg.getCurrentFrame(), 0, 0, 900, 670, null);
		g.setColor(Color.white);
		g.setFont(new Font("Monospaced", Font.BOLD, 76));
		g.drawString("Paused", 320, 300);
		g.setFont(new Font("Monospaced", Font.BOLD, 50));
		g.drawString("Press 'P' to unpause", 190, 400);
	}

	
}
