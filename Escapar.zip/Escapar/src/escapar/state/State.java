package escapar.state;

import escapar.main.World;
import java.awt.Graphics;

import escapar.main.*;

public abstract class State implements Iterations {

	//ATTRIBUTES
	protected World world;
	protected Escapar game;
	
	//CONSTRUCTOR
	public State(World world, Escapar game) {
		this.world = world;
		this.game = game;
	}
	
}
