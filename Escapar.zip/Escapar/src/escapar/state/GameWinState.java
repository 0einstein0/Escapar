package escapar.state;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import escapar.gfx.Images;
import escapar.handler.KeyHandler;
import escapar.main.Escapar;
import escapar.main.World;

public class GameWinState extends State {

	//ATTRIBUTES
	private int finalhealth; 
	
	
	//CONSTRUCTOR
	public GameWinState(World world, Escapar game, int finalhealth) {
		super(world, game);
		this.finalhealth = finalhealth;
	}

	@Override
	//there isn't much to update here
	public void update() {

	}

	@Override
	//Draw GUI
	public void draw(Graphics g) {
		g.drawImage(Images.gamewinbg, 0, 0, 900, 670, null);
		g.setColor(Color.YELLOW);
		g.setFont(new Font("Lucida Console", Font.BOLD, 60));
		g.drawString("Health : " + finalhealth, 230, 580);
	}

}
