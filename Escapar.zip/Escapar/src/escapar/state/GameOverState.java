package escapar.state;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import escapar.gfx.Images;
import escapar.handler.KeyHandler;
import escapar.main.Escapar;
import escapar.main.World;

public class GameOverState extends State {

	//ATTRIBUTES
	private int finalscore;

	//CONSTRUCTOR
	public GameOverState(World world, Escapar game, int finalscore) {
		super(world, game);
		this.finalscore = finalscore;
	}

	
	
	@Override
	//there isn't much to update here
	public void update() {
		
	}

	@Override
	//draw GUI
	public void draw(Graphics g) {
			g.drawImage(Images.gameoverbg, 0, 0, 900, 670, null);
			g.setColor(Color.YELLOW);
			g.setFont(new Font("Arial", Font.BOLD, 76));
			g.drawString("Score : " + finalscore, 250, 450);

		}

	}


