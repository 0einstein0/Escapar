package escapar.object;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import escapar.gfx.Location;
import escapar.main.Escapar;
import escapar.main.World;

public abstract class Character extends OBJECT {
	
	//ATTRIBUTES
	protected int health;
	protected float speed;
	
	//CONSTRUCTOR
	public Character(Escapar game, World world,  Location position) {
		super(game, world, position, 64, 64);
		
	}
	
	//Things that a character can do
	public abstract void move();
	public abstract void hurt();
	public abstract void die();


	//SETTERS AND GETTERS
	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public float getSpeed() {
		return speed;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}


	
}
