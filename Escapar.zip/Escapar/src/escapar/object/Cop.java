package escapar.object;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import escapar.gfx.Images;
import escapar.gfx.Location;
import escapar.main.Escapar;
import escapar.main.World;

public class Cop extends Character {

	// ATTRIBUTES
	private int moveNo; // each move path for an enemy has a certain number
	private BufferedImage face; // the texture of the enemy

	public Cop(Escapar game, World world, Location position) {
		super(game, world, position);

	}

	// Update variables based on move path
	public void update(int moveNo) {
		this.moveNo = moveNo;
		move();

	}

	// draw the enemy
	public void draw(Graphics g) {

		g.drawImage(face, (int) position.getX(), (int) position.getY(), 45, 45, null);

	}

	@Override
	// move based on move path
	public void move() {

		
		//around the outer pathway
		if (moveNo == 1) {
			if (position.x >= 790 && position.x <= 810 && position.y < 580) {
				position.y += 3;
				face = Images.cop_down;
			} else if (position.y >= 580 && position.x > 50) {
				position.x -= 3;
				face = Images.cop_left;
			} else if (position.x >= 40 && position.x <= 60 && position.y > 40) {
				position.y -= 3;
				face = Images.cop_up;
			} else if (position.y <= 40 && position.x < 800) {
				position.x += 3;
				face = Images.cop_right;
			}

		}
		
		//around the inner pathway
		if (moveNo == 2) {
			if (position.x >= 620 && position.x <= 660 && position.y < 470) {
				position.y += 3;
				face = Images.cop_down;
			} else if (position.y >= 470 && position.x > 201) {
				position.x -= 3;
				face = Images.cop_left;
			} else if (position.x >= 190 && position.x <= 210 && position.y > 150) {
				position.y -= 3;
				face = Images.cop_up;
			} else if (position.y <= 150 && position.x < 640) {
				position.x += 3;
				face = Images.cop_right;
			}
		}
		
		//up and down
		if (moveNo == 3) {
			if (position.x == 400 && position.y < 580) {
				position.y += 3;
				face = Images.cop_down;
			} else if (position.y > 580 && position.y < 590 && position.x != 401)
				position.x = 401;
			else if (position.x >= 401 && position.y > 40) {
				position.y -= 3;
				face = Images.cop_up;
			} else
				position.x = 400;
		}

	}


	@Override
	public void hurt() {
		System.out.println("YOU CANNOT HURT ME!");
	}

	@Override
	public void die() {
		System.out.println("I DO NOT DIE!");
	}

}
