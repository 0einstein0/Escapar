package escapar.object;

import escapar.main.World;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import escapar.gfx.*;
import escapar.handler.*;
import escapar.main.*;
import escapar.main.Escapar;
import escapar.state.GameOverState;

public class Pablo extends Character {
	
	//ATTRIBUTES
	protected int score;
	protected int speed = 5;

	public Pablo(Escapar game, World world, Location position) {
		super(game, world, position);
		health = 100;
		score = 0;

		//set collision area relative to player
		collisionArea.x = 8;
		collisionArea.y = 25;
		collisionArea.width = 32;
		collisionArea.height = 20;

	}


	//collects a given amount and add it to the score
	public void collect(int amount) {
		score += amount;
		if (score >= Escapar.winningscore) {
			BackGround.paththatwillopen.setSolid(false); //open physical path
		} 
	}

	
	//update
	public void update() {
		move(); 
	}

	
	//drawing, after updating
	public void draw(Graphics g) {
		
		//draws player based on direction
		if (KeyHandler.down) {
			g.drawImage(Images.pablo_down, (int) position.getX(), (int) position.getY(), 45, 45, null);
		} else if (KeyHandler.up) {
			g.drawImage(Images.pablo_up, (int) position.getX(), (int) position.getY(), 45, 45, null);
		} else if (KeyHandler.left) {
			g.drawImage(Images.pablo_left, (int) position.getX(), (int) position.getY(), 45, 45, null);
		} else if (KeyHandler.right) {
			g.drawImage(Images.pablo_right, (int) position.getX(), (int) position.getY(), 45, 45, null);
		} else
			g.drawImage(Images.pablo_down, (int) position.getX(), (int) position.getY(), 45, 45, null);

		/*
		 * g.setColor(Color.RED); g.drawRect((int) (collisionArea.x + position.x), (int)
		 * (collisionArea.y + position.y), collisionArea.width, collisionArea.height);
		 */
	}

	
	@Override
	//lose health
	public void hurt() {
		health -= 2;
		
		if (health <= 0) {
			die(); //if health is below zero, the player dies
		}

	}

	@Override
	//when the player dies, the game is set to a game over state
	public void die() {
		Escapar.currentstate = new GameOverState(world, game, score);
	}

	
	@Override
	//coordinate movements
	public void move() {
		if (KeyHandler.down)
			moveDown();
		if (KeyHandler.up)
			moveUp();
		if (KeyHandler.left)
			moveLeft();
		if (KeyHandler.right)
			moveRight();
	}

	public void moveUp() {
		int bgcol = (int) (((collisionArea.y + position.y) - speed) / BackGround.BGHEIGHT);
		int bgrow1 = (int) (((collisionArea.x + position.x)) / BackGround.BGWIDTH);
		int bgrow2 = (int) (((collisionArea.x + position.x + collisionArea.width)) / BackGround.BGWIDTH);
		if (!checkCollision(bgrow1, bgcol) && !checkCollision(bgrow2, bgcol)) {
			position.y -= speed;
		}
	}

	public void moveDown() {
		int bgcol = (int) (((collisionArea.y + position.y + collisionArea.height) + speed) / BackGround.BGHEIGHT);
		int bgrow1 = (int) (((collisionArea.x + position.x)) / BackGround.BGWIDTH);
		int bgrow2 = (int) (((collisionArea.x + position.x + collisionArea.width)) / BackGround.BGWIDTH);

		if (!checkCollision(bgrow1, bgcol) && !checkCollision(bgrow2, bgcol)) {
			position.y += speed;
		}
	}

	public void moveLeft() {
		int bgrow = (int) (((collisionArea.x + position.x) - speed) / BackGround.BGWIDTH);
		int bgcol1 = (int) (((collisionArea.y + position.y)) / BackGround.BGHEIGHT);
		int bgcol2 = (int) (((collisionArea.y + position.y + collisionArea.height)) / BackGround.BGHEIGHT);
		if (!checkCollision(bgrow, bgcol1) && !checkCollision(bgrow, bgcol2)) {
			position.x -= speed;
		}
	}

	public void moveRight() {
		int bgrow = (int) (((collisionArea.x + position.x + collisionArea.width) + speed) / BackGround.BGWIDTH);
		int bgcol1 = (int) (((collisionArea.y + position.y)) / BackGround.BGHEIGHT);
		int bgcol2 = (int) (((collisionArea.y + position.y + collisionArea.height)) / BackGround.BGHEIGHT);
		if (!checkCollision(bgrow, bgcol1) && !checkCollision(bgrow, bgcol2)) {
			position.x += speed;
		}
	}


	public int getScore() {
		return score;
	}
	

}
