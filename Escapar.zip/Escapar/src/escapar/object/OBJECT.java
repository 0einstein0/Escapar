package escapar.object;

import escapar.main.World;
import java.awt.*;
import java.awt.image.BufferedImage;

import escapar.gfx.*;
import escapar.main.*;

public abstract class OBJECT  {
	
	
	//ATTRIBUTES
	
	//Overarching Structures
	protected Escapar game;
	protected World world;
	
	//Object Attributes
	protected Location position;
	protected int width, height;
	protected boolean alive;
	protected Rectangle collisionArea;
	protected BufferedImage skin;
	
	//CONSTRUCTOR
	
	public OBJECT(Escapar game, World world, Location position, int width, int height) {
		this.game = game;
		this.world = world;
		this.position = position;
		this.width = width;
		this.height = height;
		
		collisionArea = new Rectangle();
	}
	

	//Allow any OBJECT to know if a background at a certain background coordinate is non-traversable or not
	public boolean checkCollision(int row, int col) {
		return world.getBG(row, col).isSolid();
	}
	

	//GETTERS AND SETTERS

	public Escapar getGame() {
		return game;
	}


	public void setGame(Escapar game) {
		this.game = game;
	}


	public World getWorld() {
		return world;
	}


	public void setWorld(World world) {
		this.world = world;
	}


	public Location getPosition() {
		return position;
	}


	public void setPosition(Location position) {
		this.position = position;
	}


	public int getWidth() {
		return width;
	}


	public void setWidth(int width) {
		this.width = width;
	}


	public int getHeight() {
		return height;
	}


	public void setHeight(int height) {
		this.height = height;
	}


	public boolean isAlive() {
		return alive;
	}


	public void setAlive(boolean alive) {
		this.alive = alive;
	}


	public Rectangle getCollisionArea() {
		return collisionArea;
	}


	public void setCollisionArea(Rectangle collisionArea) {
		this.collisionArea = collisionArea;
	}


	public BufferedImage getSkin() {
		return skin;
	}


	public void setSkin(BufferedImage skin) {
		this.skin = skin;
	}
	
	

	
	
	
	
}
