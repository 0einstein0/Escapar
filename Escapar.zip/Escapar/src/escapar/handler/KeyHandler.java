package escapar.handler;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import escapar.main.Iterations;
import escapar.object.Pablo;

public class KeyHandler implements KeyListener {

	/**
	 * This class basically acts to inform the game. If up is pressed the up
	 * variable is set to true, and the rest of the game can do if (KeyHandler.up)
	 * followed by whichever actions they wish. The same applies to down, left,
	 * right, etc
	 */

	public static boolean up, down, left, right; //arrow keys
	public static boolean p, s; //letters

	@Override
	public void keyTyped(KeyEvent e) {

	}

	@Override
	public void keyPressed(KeyEvent e) {

		// set to true, whichever key is pressed

		if (e.getKeyCode() == KeyEvent.VK_UP) {

			up = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {

			down = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {

			left = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			
			right = true;
		}
		if (e.getKeyCode() == KeyEvent.VK_P) {

			p = true;
		}
		
		if (e.getKeyCode() == KeyEvent.VK_S) {

			s = true;
		}
		
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// set false to all keys
		up = false;
		down = false;
		left = false;
		right = false;
		p = false;
		s = false;
	}

}
