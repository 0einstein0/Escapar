package escapar.handler;

import java.awt.event.*;

import escapar.main.Escapar;

public class MouseHandler extends MouseAdapter {

	public static boolean startbutton, aboutbutton; // main menu buttons

	@Override
	public void mouseClicked(MouseEvent e) {
		if (Escapar.currentstate == Escapar.mainmenu) {
			if (e.getX() >= 320 && e.getY() >= 420 && e.getX() <= 570 && e.getY() <= 570) {
				startbutton = true;
			}
			if (e.getX() >= 320 && e.getY() >= 550 && e.getX() <= 570 && e.getY() <= 700) {
				if (!aboutbutton) {
					aboutbutton = true;
				}
				else if (aboutbutton) {
					aboutbutton = false;
				}
			}

			// sets to true or false if the coordinates of that button is clicked
		}

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		startbutton = false;

	}

}
