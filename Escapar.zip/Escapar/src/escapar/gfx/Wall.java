package escapar.gfx;

import java.awt.image.BufferedImage;

public class Wall extends BackGround {

	//CONSTRUCTOR
	public Wall(int id, boolean solid) {
		super(Images.wall, id, solid);
	}

}
