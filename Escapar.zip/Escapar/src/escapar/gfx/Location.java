package escapar.gfx;

public class Location {

	// ATTRIBUTES
	public int x;
	public int y;

	// CONSTRUCTOR
	public Location(int i, int j) {
		x = i;
		y = j;
	}

	// Method for measuring distance between two locations
	public float measureDistance(Location a) {
		return (float) Math.sqrt(Math.pow(a.x - this.x, 2) + Math.pow(a.y - this.y, 2));
	}

	// GETTERS AND SETTERS

	public void setXY(int x, int y) {
		setX(x);
		setY(y);
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}

}
