package escapar.gfx;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import escapar.main.*;

public class BackGround {

	
	//ATTRIBUTES
	protected BufferedImage icon;
	protected final int id;
	protected boolean solid; //should the player collide 
	public static final int BGWIDTH = 43, BGHEIGHT = 42;
	public static BackGround[] bg = new BackGround[4]; //array of backgrounds based on id
	
	//Types of Backgrounds used in the Game
	public static BackGround ground = new Ground(0, false);
	public static BackGround wall = new Wall(1, true);
	public static BackGround groundwithmoney = new Ground(2, false);
	public static BackGround paththatwillopen = new Ground(3, true);
	
	
	//CONSTRUCTOR
	public BackGround(BufferedImage icon, int id, boolean solid) {
		this.icon = icon;
		this.id = id;
		this.solid = solid;
		
		bg[id] = this; //assign to static array based on ID
	}



	//Draws a Background element at a given location
	public void draw(Graphics g, int x, int y){
		g.drawImage(icon, x, y, BGWIDTH, BGHEIGHT, null);
	}
	
	
	//GETTERS AND SETTERS
	public int getId(){
		return id;
	}
	
	public boolean isSolid() {
		return solid;
	}

	public void setSolid(boolean solid) {
		this.solid = solid;
	}
	
	


}
