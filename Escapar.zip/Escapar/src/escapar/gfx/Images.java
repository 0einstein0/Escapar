package escapar.gfx;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;


public class Images {
	
	//object dimensions
	private static final int width = 32 ,height = 32;
	private static final int pwidth = 43 ,pheight = 45;
	private static final int cwidth = 27 ,cheight = 32;
	
	//game objects
	public static BufferedImage ground, wall;
	public static Animation coin;
	public static BufferedImage[] treasurebox;

	//player and enemy
	public static BufferedImage pablo_down, pablo_up, pablo_left, pablo_right;
	public static BufferedImage cop_down, cop_up, cop_left, cop_right;
	
	//state backgrounds
	public static Animation menubg;
	public static BufferedImage gameoverbg;
	public static BufferedImage gamewinbg;
	public static Animation pausebg;
	
	//other
	public static BufferedImage startbutton;
	public static BufferedImage title;
	public static BufferedImage closedoor;
	public static BufferedImage[] opendoor;
	public static BufferedImage counterholder;
	public static BufferedImage aboutbutton;
	public static BufferedImage abouttext;
	
	
	public static void initialise() {
		//initialising spritesheets
		SpriteSheet bgsheet = new SpriteSheet(loadImage("res/images/bg.png"));
		SpriteSheet pablosheet = new SpriteSheet(loadImage("res/images/pablo.png"));
		SpriteSheet copsheet = new SpriteSheet(loadImage("res/images/cop.png"));
		SpriteSheet coinsheet = new SpriteSheet(loadImage("res/images/coins.png"));

		
		//wall and ground
		wall = bgsheet.getSprite(0, height, width, height);
		ground = bgsheet.getSprite(width*5, height*3, width, height);
		
		
		//initialising animation for main menu background
		BufferedImage[] menubgarr = new BufferedImage[6];
		menubgarr[0] = loadImage("res/images/MenuGraphics/menubg0.gif");
		menubgarr[1] = loadImage("res/images/MenuGraphics/menubg1.gif");
		menubgarr[2] = loadImage("res/images/MenuGraphics/menubg2.gif");
		menubgarr[3] = loadImage("res/images/MenuGraphics/menubg3.gif");
		menubgarr[4] = loadImage("res/images/MenuGraphics/menubg4.gif");
		menubgarr[5] = loadImage("res/images/MenuGraphics/menubg5.gif");
		
		menubg = new Animation(100, menubgarr);
		
		//initialising animation for pause menu background
		BufferedImage[] pausebgarr = new BufferedImage[10];
		for (int i = 0; i < 10; i++) {
			pausebgarr[i] = loadImage("res/images/PauseGraphics/frame_00" + i + "_delay-0.08s.gif");
		}
		
		pausebg = new Animation(100, pausebgarr);
		
		//game over and win backgrounds
		gameoverbg = loadImage("res/images/gameover.jpg");
		gamewinbg = loadImage("res/images/win.png");
		
		
		//initialising coin animation
		BufferedImage[] coinarr = new BufferedImage[8];
		coinarr[0] = coinsheet.getSprite(0, 0, 27, 31);
		coinarr[1] = coinsheet.getSprite(28, 0, 30, 31);
		coinarr[2] = coinsheet.getSprite(60, 0, 30, 31);
		coinarr[3] = coinsheet.getSprite(90, 0, 30, 31);
		coinarr[4] = coinsheet.getSprite(120, 0, 30, 31);
		coinarr[5] = coinsheet.getSprite(154, 0, 30, 31);
		coinarr[6] = coinsheet.getSprite(186, 0, 30, 31);
		coinarr[7] = coinsheet.getSprite(220, 0, 30, 31);
		
		coin = new Animation(150, coinarr);
		
		//initialising both states of treasure box
		treasurebox = new BufferedImage[2];
		treasurebox[0] = loadImage("res/images/treasureclose.png");
		treasurebox[1] = loadImage("res/images/treasureopen.png");
		
		
		
		//initalising all directions of player and enemy
		pablo_down = pablosheet.getSprite(0, 0, pwidth, pheight);
		pablo_left = pablosheet.getSprite(0,pheight+4 , pwidth, pheight);
		pablo_right = pablosheet.getSprite(0, (pheight*2)+6, pwidth, pheight);
		pablo_up = pablosheet.getSprite(pwidth, (pheight*3)+10, pwidth, pheight);
		
		cop_down = copsheet.getSprite(96, 0, cwidth, cheight);
		cop_left = copsheet.getSprite(96, cheight, cwidth, cheight);
		cop_right = copsheet.getSprite(96, cheight*2, cwidth, cheight);
		cop_up = copsheet.getSprite(96, cheight*3, cwidth, cheight);
		
		
		
		//initialising other images
		startbutton = loadImage("res/images/button.png");
		title = loadImage("res/images/title.png");
		closedoor = Images.loadImage("res/images/door.jpeg");
		
		opendoor = new BufferedImage[3];
		opendoor[0] = loadImage("res/images/opendoor0.png");
		opendoor[1] = loadImage("res/images/opendoor1.png");
		opendoor[2] = loadImage("res/images/opendoor2.png");
		
		counterholder = loadImage("res/images/counterholder.jpg");
		
		aboutbutton = loadImage("res/images/about.png");
		abouttext = loadImage("res/images/abouttext.png");
		
	}
		
	
	//LOADING IMAGES (FILE MANAGEMENT)
	
	public static BufferedImage loadImage(String path){
		try {
			return ImageIO.read(new File(path));
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		return null;
	}
	
	
}
