package escapar.gfx;

import java.awt.image.BufferedImage;

public class SpriteSheet {
	
private BufferedImage sheet;
	

	//CONSTRUCTOR
	public SpriteSheet(BufferedImage sheet){
		this.sheet = sheet;
	}
	
	//Method to crop subimage from sprite
	public BufferedImage getSprite(int x, int y, int width, int height){
		return sheet.getSubimage(x, y, width, height);
	}

	
}