package escapar.gfx;

import java.awt.image.BufferedImage;

public class Ground extends BackGround {

	//CONSTRUCTOR
	public Ground(int id, boolean solid) {
		super(Images.ground, id, solid);	
	}

}
