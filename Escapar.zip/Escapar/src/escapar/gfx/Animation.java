package escapar.gfx;

import java.awt.image.BufferedImage;

public class Animation {
	
	//ATTRIBUTES
	private int timeOfFrame, index; 
	private long lastTime, timer;
	private BufferedImage[] frames;
	
	//CONSTRUCTOR
	public Animation(int slow, BufferedImage[] frames){
		this.timeOfFrame = slow;
		this.frames = frames;
		index = 0;
		timer = 0;
		lastTime = System.currentTimeMillis();
	}
	
	//changes the current frame index based on time passed
	public void update(){
		timer += System.currentTimeMillis() - lastTime;
		lastTime = System.currentTimeMillis();
		
		if(timer > timeOfFrame){
			index++;
			timer = 0;
			if(index >= frames.length)
				index = 0;
		}
	}
	
	//retrived the current frame in the form of an BufferedImage (or subclass thereof)
	public BufferedImage getCurrentFrame(){
		return frames[index];
	}

}