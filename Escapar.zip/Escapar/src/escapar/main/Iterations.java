package escapar.main;

import java.awt.Graphics;

public interface Iterations {
	void update(); //updates variables
	void draw(Graphics g); //draws graphics to screen based on variables
}
