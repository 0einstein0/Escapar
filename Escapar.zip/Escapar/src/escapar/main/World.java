package escapar.main;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import escapar.gfx.*;
import escapar.main.Escapar;
import escapar.main.Iterations;
import escapar.object.*;
import escapar.state.GameWinState;

public class World implements Iterations {
	
	//ATTRIBUTES
	private Location spawn = new Location(0, 0);
	private Escapar game;
	
	//World Objects
	private Pablo pablo = new Pablo(game, this, spawn);
	private Cop cop1 = new Cop(game, this, new Location(800, 45));
	private Cop cop2 = new Cop(game, this, new Location(640, 150));
	private Cop cop3 = new Cop(game, this, new Location(400, 45));
	
	//to store position and state of money and treasure
	public static boolean[][] moneymap;
	public static boolean treasurebox = true;
	
	//helper variable for smooth door opening
	private int wait = 0;

	//Map info
	private int[][] bg;
	private int height;
	private int width;
	
	
	//CONSTRUCTOR
	public World(Escapar game, String path) {
		this.game = game;
		loadLevel(path);
		pablo.getPosition().setXY(spawn.getX(), spawn.getY()); //set player spawn position
	}

	
	//allow the game mechanics to know which tile is in a certain row and column of the map
	public BackGround getBG(int row, int col) {
		try {
		BackGround t = BackGround.bg[bg[row][col]];
		if (t == null)
			return BackGround.wall;
		return t;
		}
		catch (ArrayIndexOutOfBoundsException e) {
			Escapar.currentstate = new GameWinState(this, game, pablo.getHealth()); //if the player exits the screen, the player wins 
			return BackGround.ground;
		}
	}

	//load level from text file
	public void loadLevel(String path) {
		String file = loadFileAsString(path);
		String[] tokens = file.split("\\s+");
		width = parseInt(tokens[0]);
		height = parseInt(tokens[1]);
		spawn.setX(parseInt(tokens[2]));
		spawn.setY(parseInt(tokens[3]));

		bg = new int[width][height];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				bg[x][y] = parseInt(tokens[(x + y * width) + 4]);
			}
		}
		
		moneymap = new boolean[21][16];

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				if (bg[x][y] == 2) {
					moneymap[x][y] = true;
				}
			}
		}
	}

	
	//update method
	@Override
	public void update() {
		
		//update game objects
		pablo.update();
		cop1.update(1);
		cop2.update(2);
		cop3.update(3);
		
		//update animation of coin
		Images.coin.update();
		
		
		//money and treasure mechanics
		
		
		int pablosRow = (int) (pablo.getPosition().x / BackGround.BGWIDTH); //which row is player in
		int pablosCol = (int) (pablo.getPosition().y / BackGround.BGHEIGHT) + 1; //which column is player in (with practical correction)
		
		//collecting money
		if (getBG(pablosRow , pablosCol).getId() == 2 && moneymap[pablosRow][pablosCol] == true) {
			moneymap[pablosRow][pablosCol] = false;
			pablo.collect(1);
		}
		
		//collecting treasure
		if (pablosRow == 9 && pablosCol == 8 && treasurebox == true) {
			treasurebox = false;
			pablo.collect(500);
		}
			
		//interacting with enemies
		if (pablo.getPosition().measureDistance(cop1.getPosition()) < 30 || pablo.getPosition().measureDistance(cop2.getPosition()) < 30 || pablo.getPosition().measureDistance(cop3.getPosition()) < 30) {
			pablo.hurt();
		}
	}

	@Override
	public void draw(Graphics g) {
		//drawing the map
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				getBG(x, y).draw(g, x * BackGround.BGWIDTH, y * BackGround.BGHEIGHT);
			}
		}

		
		//drawing (and not drawing) the money and treasure based on the moneymap and treasure variables
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				if (moneymap[x][y])
					g.drawImage(Images.coin.getCurrentFrame(), x * BackGround.BGWIDTH + 20, y * BackGround.BGHEIGHT + 20, 15, 15, null);
				if (x == 9 && y == 8) {
					if (treasurebox)
						g.drawImage(Images.treasurebox[0],  x * BackGround.BGWIDTH + 20, y * BackGround.BGHEIGHT - 20, 50, 45, null);
					if (!treasurebox) 
						g.drawImage(Images.treasurebox[1],  x * BackGround.BGWIDTH + 20, y * BackGround.BGHEIGHT - 20, 50, 45, null);
				}
			}
		}
		
		
		//drawing the end game door based closed, only to open when winning score has been reached
		if (pablo.getScore() < Escapar.winningscore) 
			g.drawImage(Images.closedoor, 380, 0,100 , 42, null);
		//door opens in an animation before being permanently open
		else {
			if (wait < 70) {
				if (wait < 20) 
					g.drawImage(Images.opendoor[0], 380, 0,100 , 42, null);
				else if (wait < 50) 
					g.drawImage(Images.opendoor[1], 380, 0,100 , 42, null);
				else if (wait < 70) 
					g.drawImage(Images.opendoor[2], 380, 0,100 , 42, null);
				wait++;
			}
			else {
				g.drawImage(Images.loadImage("res/images/opendoor2.png"), 380, 0,100 , 42, null);
			}
			
		}
		
		
		//draw game objects
		pablo.draw(g);
		cop1.draw(g);
		cop2.draw(g);
		cop3.draw(g);
		
		//draw the counter holder
		g.drawImage(Images.counterholder, 680, 0, 220, 50, null);

	}

	
	
	// FILE MANAGEMENT to load level document
	public static String loadFileAsString(String path) {
		StringBuilder builder = new StringBuilder();

		try {
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line;
			while ((line = br.readLine()) != null)
				builder.append(line + "\n");

			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return builder.toString();
	}

	public static int parseInt(String number) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	
	//GETTERS AND SETTERS
	public Pablo getPablo() {
		return pablo;
	}

	public void setPablo(Pablo pablo) {
		this.pablo = pablo;
	}

}
