package escapar.main;

import java.awt.*;
import javax.swing.*;

public class Window {
	
	//ATTRIBUTES
	private JFrame window;
	private Canvas board;
	
	public final static int width = 900, height = 670; //window dimensions
	
	
	//CONSTRUCTOR to set up base GUI
	public Window() {
		window = new JFrame("Escapar");
		window.setSize(width, height);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		board = new Canvas();
		board.setPreferredSize(new Dimension(width, height));
		board.setMaximumSize(new Dimension(width, height));
		board.setMinimumSize(new Dimension(width, height));
		board.setFocusable(false);
		
		window.add(board);
		window.pack();
	}
	
	//getters

	public Canvas getBoard() {
		return board;
	}

	public JFrame getWindow() {
		return window;
	}

	
}
