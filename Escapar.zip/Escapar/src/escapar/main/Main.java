package escapar.main;

import escapar.object.*;


public class Main {

	public static void main(String[] args) {
		new Escapar().start(); //program begins!
            PlaySound.playMusic();
	}

}